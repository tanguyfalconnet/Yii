<?php
/* @var $this yii\web\View */

$this->title = 'Tartine-toi';
?>
<div class="site-index">

    <div class="jumbotron">
        <h1>Welcome friend!</h1>

        <p class="lead">You can now access to some fucking amazing features !</p>

        </div>
</div>
